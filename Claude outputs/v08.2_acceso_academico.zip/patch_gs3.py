# Agrega a 01_Script_Cloud_Completo.gs las rutas de 03_Asignaciones_Academico.gs (v08.2).
# Uso (desde la raíz del repo):  python patch_gs3.py
# Es idempotente: si las rutas ya están, no hace nada.
import sys
p = 'app/Backend_Scripts/01_Script_Cloud_Completo.gs'
raw = open(p, encoding='utf-8', newline='').read()
crlf = '\r\n' in raw
s = raw.replace('\r\n', '\n')

if 'asignaciones_docentes' in s:
    print('Las rutas v08.2 ya estaban en', p); sys.exit(0)
for viejo in ("'examen_aprobar'", "'examen_rechazar'", "'examen_estado_aprobacion'", "'examen_listar_pendientes_aprobacion'"):
    if viejo in s:
        sys.exit('ATENCIÓN: 01 ya define la ruta ' + viejo + '. Revisar a mano antes de aplicar.')

a = "  // ── CONSULTAR PAGOS ──\n  if (action === 'consultar_pagos') {"
b = "  // ── GUARDAR RESPUESTAS DE EXAMEN (detalle pregunta por pregunta) ──\n  if (data.action === 'guardar_respuestas_examen') {"
if s.count(a) != 1 or s.count(b) != 1:
    sys.exit('No se encontraron los puntos de inserción esperados (GET: %d, POST: %d).' % (s.count(a), s.count(b)))

get = """  // ── ACCESO ACADÉMICO v08.2 (lógica en 03_Asignaciones_Academico.gs) ──
  if (action === 'asignaciones_docentes' || action === 'examen_listar_pendientes_aprobacion' || action === 'examen_estado_aprobacion') {
    try {
      if (action === 'asignaciones_docentes') return responderJSON(cvAsigDocentesListar(ss, e.parameter));
      if (action === 'examen_listar_pendientes_aprobacion') return responderJSON(cvExamenAprobLista(ss, e.parameter));
      return responderJSON(cvExamenAprobEstado(ss, e.parameter));
    } catch (error) { return responderJSON({ ok: false, error: error.message, aprobado: false }); }
  }

"""
post = """  // ── ACCESO ACADÉMICO v08.2 (lógica en 03_Asignaciones_Academico.gs) ──
  if (['asignacion_guardar', 'asignacion_revocar', 'asignacion_docente_decidir', 'examen_aprobar', 'examen_rechazar', 'examen_revocar_aprobacion'].indexOf(data.action) >= 0) {
    try {
      if (data.action === 'asignacion_guardar') return responderJSON(cvAsigGuardar(ss, data));
      if (data.action === 'asignacion_revocar') return responderJSON(cvAsigRevocar(ss, data));
      if (data.action === 'asignacion_docente_decidir') return responderJSON(cvAsigDocenteDecidir(ss, data));
      var estadoAprob = data.action === 'examen_aprobar' ? 'aprobado' : (data.action === 'examen_rechazar' ? 'rechazado' : 'pendiente');
      return responderJSON(cvExamenAprobDecidir(ss, data, estadoAprob));
    } catch (error) { return responderJSON({ ok: false, error: error.message }); }
  }

"""
s = s.replace(a, get + a).replace(b, post + b)
out = s.replace('\n', '\r\n') if crlf else s
open(p, 'w', encoding='utf-8', newline='').write(out)
print('Rutas v08.2 agregadas a', p, '(CRLF conservado)' if crlf else '')
